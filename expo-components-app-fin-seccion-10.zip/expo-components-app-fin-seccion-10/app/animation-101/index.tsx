import { View, Text } from 'react-native';

const Animation101Screen = () => {
  return (
    <View>
      <Text>Animation101Screen</Text>
    </View>
  );
};
export default Animation101Screen;
