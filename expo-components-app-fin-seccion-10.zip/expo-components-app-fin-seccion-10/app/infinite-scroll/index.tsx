import { View, Text } from 'react-native';

const InfiniteScrollScreen = () => {
  return (
    <View>
      <Text>InfiniteScrollScreen</Text>
    </View>
  );
};
export default InfiniteScrollScreen;
