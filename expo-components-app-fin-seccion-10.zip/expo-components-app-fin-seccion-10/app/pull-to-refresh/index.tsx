import { View, Text } from 'react-native';

const PullToRefreshScreen = () => {
  return (
    <View>
      <Text>PullToRefreshScreen</Text>
    </View>
  );
};
export default PullToRefreshScreen;
