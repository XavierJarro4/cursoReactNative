import { View, Text } from 'react-native';

const AlertsScreen = () => {
  return (
    <View>
      <Text>AlertsScreen</Text>
    </View>
  );
};
export default AlertsScreen;
