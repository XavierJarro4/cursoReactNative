import { View, Text } from 'react-native';
const ProfileScreen = () => {
  return (
    <View>
      <Text>Profile</Text>
    </View>
  );
};
export default ProfileScreen;
