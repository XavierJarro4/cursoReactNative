import { View, Text } from 'react-native';
const SettingsScreen = () => {
  return (
    <View>
      <Text>Settings</Text>
    </View>
  );
};
export default SettingsScreen;
