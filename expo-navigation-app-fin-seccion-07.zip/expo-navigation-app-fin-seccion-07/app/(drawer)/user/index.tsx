import { View, Text } from 'react-native';
const UserScreen = () => {
  return (
    <View>
      <Text>UserScreen</Text>
    </View>
  );
};
export default UserScreen;
