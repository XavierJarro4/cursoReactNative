import { View, Text } from 'react-native';
const FavoritesScreen = () => {
  return (
    <View>
      <Text>FavoritesScreen</Text>
    </View>
  );
};
export default FavoritesScreen;
