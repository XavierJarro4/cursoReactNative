import { View, Text } from 'react-native';
const HomeScreen = () => {
  return (
    <View>
      <Text>Home</Text>
    </View>
  );
};
export default HomeScreen;
