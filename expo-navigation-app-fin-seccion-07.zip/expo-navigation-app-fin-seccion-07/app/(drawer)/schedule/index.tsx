import { View, Text } from 'react-native';
const ScheduleScreen = () => {
  return (
    <View>
      <Text>ScheduleScreen</Text>
    </View>
  );
};
export default ScheduleScreen;
