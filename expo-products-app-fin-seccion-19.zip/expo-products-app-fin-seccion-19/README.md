# ProductsApp

## Dev

1. Install dependencies `bun install`
2. Clonar `.env.template` a `.env` y cambiar la dirección ip
3. Ejecutar `bun start`
