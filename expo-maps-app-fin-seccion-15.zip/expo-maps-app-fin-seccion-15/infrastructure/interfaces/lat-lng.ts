export interface LatLng {
  latitude: number;
  longitude: number;
}
