import { View, Text } from 'react-native';
const MapsApp = () => {
  return (
    <View>
      <Text>MapsApp</Text>
    </View>
  );
};
export default MapsApp;
