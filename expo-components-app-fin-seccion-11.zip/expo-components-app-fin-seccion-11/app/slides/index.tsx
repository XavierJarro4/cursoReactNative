import { View, Text } from 'react-native';

const SlidesScreen = () => {
  return (
    <View>
      <Text>SlidesScreen</Text>
    </View>
  );
};
export default SlidesScreen;
