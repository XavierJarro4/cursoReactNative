import { View, Text } from 'react-native';

const TextInputsScreen = () => {
  return (
    <View>
      <Text>TextInputsScreen</Text>
    </View>
  );
};
export default TextInputsScreen;
