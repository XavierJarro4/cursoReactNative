import { View, Text } from 'react-native';

const SectionListScreen = () => {
  return (
    <View>
      <Text>SectionListScreen</Text>
    </View>
  );
};
export default SectionListScreen;
