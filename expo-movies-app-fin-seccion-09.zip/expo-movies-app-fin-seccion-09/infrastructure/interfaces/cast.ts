export interface Cast {
  id: number;
  name: string;
  character: string;
  avatar: string;
}
