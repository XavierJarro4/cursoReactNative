import { View, Text } from 'react-native';
const MapScreen = () => {
  return (
    <View>
      <Text>Map Screen</Text>
    </View>
  );
};
export default MapScreen;
