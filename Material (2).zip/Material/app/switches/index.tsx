import { View, Text } from 'react-native';

const Switches = () => {
  return (
    <View>
      <Text>Switches</Text>
    </View>
  );
};
export default Switches;
