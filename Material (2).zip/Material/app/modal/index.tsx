import { View, Text } from 'react-native';

const ModalScreen = () => {
  return (
    <View>
      <Text>ModalScreen</Text>
    </View>
  );
};
export default ModalScreen;
