import { View, Text } from 'react-native';
const ComponentsApp = () => {
  return (
    <View>
      <Text>ComponentsApp</Text>
    </View>
  );
};
export default ComponentsApp;
