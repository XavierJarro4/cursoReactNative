import { View, Text } from 'react-native';

const ThemesScreen = () => {
  return (
    <View>
      <Text>ThemesScreen</Text>
    </View>
  );
};
export default ThemesScreen;
