import { View, Text } from 'react-native';

const Animation102Screen = () => {
  return (
    <View>
      <Text>Animation102Screen</Text>
    </View>
  );
};
export default Animation102Screen;
