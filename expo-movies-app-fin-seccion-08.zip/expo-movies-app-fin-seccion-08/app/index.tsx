import { Redirect } from 'expo-router';

const MoviesApp = () => {
  return <Redirect href="/home" />;
};
export default MoviesApp;
